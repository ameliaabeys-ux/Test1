package com.genshinhub.frontend

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.ConfirmationNumber
import androidx.compose.material.icons.outlined.Leaderboard
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF050817)
private val SurfaceColor = Color(0xFF0B1024)
private val SurfaceDeep = Color(0xFF090E20)
private val Border = Color(0xFF202B50)
private val Purple = Color(0xFF9C2FFF)
private val TextMain = Color(0xFFF6F4FA)
private val TextMuted = Color(0xFF8D96B1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GenshinHub() }
    }
}

@Composable
private fun GenshinHub() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = SurfaceColor,
            primary = Purple
        )
    ) {
        var nav by remember { mutableIntStateOf(0) }
        var query by remember { mutableStateOf("") }
        var element by remember { mutableIntStateOf(-1) }
        var favorites by remember { mutableStateOf(setOf<Int>()) }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Bg)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(horizontal = 26.dp)
            ) {
                Header()
                Spacer(Modifier.height(18.dp))
                HeroBanner()
                Spacer(Modifier.height(18.dp))
                SearchAndFavorite(query) { query = it }
                Spacer(Modifier.height(16.dp))
                Elements(element) { element = it }
                Spacer(Modifier.height(18.dp))
                SectionHeader()
                Spacer(Modifier.height(12.dp))

                val images = listOf(
                    R.drawable.card1, R.drawable.card2, R.drawable.card3,
                    R.drawable.card4, R.drawable.card5, R.drawable.card6
                )
                val names = listOf(
                    "Althea", "Alyosha", "Columbina",
                    "Character", "Character", "Ineffa"
                )

                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 112.dp)
                ) {
                    itemsIndexed(images) { index, image ->
                        CharacterCard(
                            image = image,
                            name = names[index],
                            favorite = index in favorites,
                            onFavorite = {
                                favorites = if (index in favorites)
                                    favorites - index else favorites + index
                            }
                        )
                    }
                }
            }

            BottomNavigation(
                selected = nav,
                onSelected = { nav = it },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
private fun Header() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HeaderButton(Icons.Default.Menu)

        Spacer(Modifier.width(10.dp))

        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = "GenshinHub",
            modifier = Modifier
                .weight(1f)
                .height(62.dp)
                .padding(horizontal = 4.dp),
            contentScale = ContentScale.Fit
        )

        Spacer(Modifier.width(8.dp))

        Box {
            HeaderButton(Icons.Outlined.ConfirmationNumber)
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 1.dp, y = (-2).dp)
                    .size(23.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE94D59)),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.material3.Text(
                    "3",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }

        Spacer(Modifier.width(8.dp))
        HeaderButton(Icons.Outlined.NotificationsNone)
    }
}

@Composable
private fun HeaderButton(icon: ImageVector) {
    Box(
        modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .background(SurfaceDeep)
            .border(1.dp, Border, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(
            icon,
            contentDescription = null,
            tint = TextMain,
            modifier = Modifier.size(29.dp)
        )
    }
}

@Composable
private fun HeroBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(25.dp))
            .border(1.dp, Color(0xFF9B69C5), RoundedCornerShape(25.dp))
    ) {
        Image(
            painter = painterResource(R.drawable.banner),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 9.dp)
                .width(52.dp)
                .height(5.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.White.copy(alpha = .8f))
        )
    }
}

@Composable
private fun SearchAndFavorite(
    query: String,
    onQuery: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            modifier = Modifier
                .weight(1f)
                .height(72.dp),
            singleLine = true,
            placeholder = {
                androidx.compose.material3.Text(
                    "Search characters...",
                    color = TextMuted,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            leadingIcon = {
                androidx.compose.material3.Icon(
                    Icons.Default.Search,
                    null,
                    tint = TextMuted,
                    modifier = Modifier.size(28.dp)
                )
            },
            shape = RoundedCornerShape(23.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Purple,
                unfocusedBorderColor = Border,
                focusedContainerColor = SurfaceDeep,
                unfocusedContainerColor = SurfaceDeep,
                cursorColor = Purple
            )
        )

        Box(
            modifier = Modifier
                .width(76.dp)
                .height(72.dp)
                .clip(RoundedCornerShape(23.dp))
                .background(SurfaceDeep)
                .border(1.dp, Border, RoundedCornerShape(23.dp)),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.material3.Icon(
                Icons.Outlined.StarBorder,
                null,
                tint = TextMain,
                modifier = Modifier.size(34.dp)
            )
        }
    }
}

@Composable
private fun Elements(
    selected: Int,
    onSelected: (Int) -> Unit
) {
    val colors = listOf(
        Color(0xFFFF654D),
        Color(0xFF29B7FF),
        Color(0xFF52D7AF),
        Color(0xFFB56CFF),
        Color(0xFF9DDC38),
        Color(0xFF76D8FF),
        Color(0xFFFFB52D)
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        colors.forEachIndexed { index, color ->
            val active = selected == index
            val stroke by animateColorAsState(
                if (active) color else Border,
                tween(180),
                label = "elementStroke"
            )

            Box(
                modifier = Modifier
                    .size(66.dp)
                    .clip(CircleShape)
                    .background(SurfaceDeep)
                    .border(2.dp, stroke, CircleShape)
                    .clickable {
                        onSelected(if (active) -1 else index)
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = .14f)),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.material3.Icon(
                        Icons.Default.AutoAwesome,
                        null,
                        tint = color,
                        modifier = Modifier.size(25.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeader() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        androidx.compose.material3.Text(
            "All Characters",
            color = TextMain,
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold
        )

        Spacer(Modifier.width(9.dp))

        androidx.compose.material3.Text(
            "14 Characters",
            color = TextMuted,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.weight(1f))

        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(SurfaceDeep)
                .border(1.dp, Border, RoundedCornerShape(15.dp))
                .padding(5.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Purple),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.material3.Icon(
                    Icons.Default.GridView,
                    null,
                    tint = Color.White,
                    modifier = Modifier.size(27.dp)
                )
            }
        }
    }
}

@Composable
private fun CharacterCard(
    image: Int,
    name: String,
    favorite: Boolean,
    onFavorite: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF1A203A), Color(0xFF0D1229))
                )
            )
            .border(1.dp, Border, RoundedCornerShape(20.dp))
            .padding(6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(.67f)
                .clip(RoundedCornerShape(16.dp))
        ) {
            Image(
                painter = painterResource(image),
                contentDescription = name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(31.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = .36f))
                    .clickable { onFavorite() },
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.material3.Icon(
                    if (favorite)
                        androidx.compose.material.icons.Icons.Filled.Favorite
                    else
                        Icons.Outlined.FavoriteBorder,
                    null,
                    tint = if (favorite) Color(0xFFFF4D72) else Color.White,
                    modifier = Modifier.size(19.dp)
                )
            }
        }

        Spacer(Modifier.height(5.dp))

        androidx.compose.material3.Text(
            "★★★★★",
            color = Color(0xFFFFD044),
            fontSize = 12.sp,
            maxLines = 1
        )

        androidx.compose.material3.Text(
            name,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1
        )

        androidx.compose.material3.Text(
            "↗  Polearm",
            color = TextMuted,
            fontSize = 11.sp,
            maxLines = 1
        )

        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun BottomNavigation(
    selected: Int,
    onSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val labels = listOf(
        "Characters",
        "Weapons",
        "Artifacts",
        "Teams",
        "Tier List"
    )

    val icons = listOf(
        Icons.Default.Person,
        Icons.Default.Shield,
        Icons.Default.AutoAwesome,
        Icons.Default.Groups,
        Icons.Outlined.Leaderboard
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(82.dp),
        shape = RoundedCornerShape(35.dp),
        color = Color(0xFF0D111C),
        shadowElevation = 18.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            labels.forEachIndexed { index, label ->
                val active = selected == index

                val width by animateDpAsState(
                    targetValue = if (active) 142.dp else 50.dp,
                    animationSpec = tween(220),
                    label = "navWidth"
                )

                Box(
                    modifier = Modifier
                        .height(62.dp)
                        .width(width)
                        .clip(RoundedCornerShape(31.dp))
                        .background(
                            if (active) Purple else Color.Transparent
                        )
                        .clickable { onSelected(index) },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        androidx.compose.material3.Icon(
                            icons[index],
                            null,
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )

                        if (active) {
                            Spacer(Modifier.width(8.dp))
                            androidx.compose.material3.Text(
                                label,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
