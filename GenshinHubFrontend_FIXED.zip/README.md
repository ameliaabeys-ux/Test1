# GenshinHub Frontend Prototype

Android frontend prototype built with Kotlin + Jetpack Compose.

## What is included
- Dark GenshinHub-inspired home screen
- Header with menu / logo / notifications
- Banner
- Search field
- Element filter row
- Character grid
- Favorite interaction
- Animated floating bottom navigation
- No backend/API

Open the project in Android Studio and sync Gradle.
