package com.genshinhub.frontend

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF050817)
private val Surface = Color(0xFF0A1026)
private val Surface2 = Color(0xFF101733)
private val Line = Color(0xFF202B50)
private val Purple = Color(0xFF9A35FF)
private val TextMain = Color(0xFFF5F4FA)
private val TextMuted = Color(0xFF8C96B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GenshinHubApp() }
    }
}

@Composable
fun GenshinHubApp() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Surface,
            primary = Purple
        )
    ) {
        var selectedNav by remember { mutableIntStateOf(0) }
        var search by remember { mutableStateOf("") }
        var selectedElement by remember { mutableIntStateOf(-1) }
        var favorites by remember { mutableStateOf(setOf<Int>()) }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Bg)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(horizontal = 28.dp)
            ) {
                Header()
                Spacer(Modifier.height(22.dp))
                Banner()
                Spacer(Modifier.height(24.dp))
                SearchRow(search) { search = it }
                Spacer(Modifier.height(18.dp))
                ElementFilter(selectedElement) { selectedElement = it }
                Spacer(Modifier.height(24.dp))
                SectionTitle()
                Spacer(Modifier.height(16.dp))

                val names = listOf("Althea", "Alyosha", "Columbina", "Character", "Character", "Ineffa")
                val cards = listOf(
                    R.drawable.card1, R.drawable.card2, R.drawable.card3,
                    R.drawable.card4, R.drawable.card5, R.drawable.card6
                )

                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 130.dp)
                ) {
                    itemsIndexed(cards) { index, res ->
                        CharacterCard(
                            image = res,
                            title = names[index],
                            favorite = index in favorites,
                            onFavorite = {
                                favorites = if (index in favorites)
                                    favorites - index else favorites + index
                            }
                        )
                    }
                }
            }

            FloatingBottomBar(
                selected = selectedNav,
                onSelected = { selectedNav = it },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 10.dp)
            )
        }
    }
}

@Composable
private fun Header() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RoundButton(Icons.Default.Menu)
        Spacer(Modifier.weight(1f))
        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = "GenshinHub",
            modifier = Modifier
                .width(190.dp)
                .height(70.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box {
                RoundButton(Icons.Outlined.ConfirmationNumber)
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 2.dp, y = (-2).dp)
                        .size(21.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE84D59)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("3", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            RoundButton(Icons.Outlined.Notifications)
        }
    }
}

@Composable
private fun RoundButton(icon: ImageVector) {
    Box(
        modifier = Modifier
            .size(74.dp)
            .clip(CircleShape)
            .background(Surface)
            .border(1.dp, Line, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = TextMain, modifier = Modifier.size(31.dp))
    }
}

@Composable
private fun Banner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(360.dp)
            .clip(RoundedCornerShape(28.dp))
            .border(1.dp, Color(0xFF8D66B8), RoundedCornerShape(28.dp))
    ) {
        Image(
            painter = painterResource(R.drawable.banner),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp)
                .size(width = 70.dp, height = 6.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = .75f))
        )
    }
}

@Composable
private fun SearchRow(value: String, onValue: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onValue,
            modifier = Modifier.weight(1f),
            placeholder = {
                Text(
                    "Search characters...",
                    color = TextMuted,
                    fontWeight = FontWeight.Bold
                )
            },
            leadingIcon = {
                Icon(Icons.Default.Search, null, tint = TextMuted)
            },
            singleLine = true,
            shape = RoundedCornerShape(25.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Purple,
                unfocusedBorderColor = Line,
                focusedContainerColor = Surface,
                unfocusedContainerColor = Surface
            )
        )
        Box(
            modifier = Modifier
                .size(95.dp)
                .clip(RoundedCornerShape(25.dp))
                .background(Surface)
                .border(1.dp, Line, RoundedCornerShape(25.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.StarBorder, null, tint = TextMain, modifier = Modifier.size(38.dp))
        }
    }
}

@Composable
private fun ElementFilter(selected: Int, onSelected: (Int) -> Unit) {
    val colors = listOf(
        Color(0xFFFF654D), Color(0xFF32B9FF), Color(0xFF55D6AE),
        Color(0xFFB76BFF), Color(0xFF9BDB39), Color(0xFF74D8FF), Color(0xFFFFB52E)
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        colors.forEachIndexed { i, c ->
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(Surface)
                    .border(
                        1.5.dp,
                        if (selected == i) c else Line,
                        CircleShape
                    )
                    .clickable { onSelected(if (selected == i) -1 else i) },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(35.dp)
                        .clip(CircleShape)
                        .background(c.copy(alpha = .15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.AutoAwesome,
                        null,
                        tint = c,
                        modifier = Modifier.size(25.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitle() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            "All Characters",
            color = TextMain,
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold
        )
        Spacer(Modifier.width(10.dp))
        Text(
            "14 Characters",
            color = TextMuted,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.weight(1f))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Surface)
                .border(1.dp, Line, RoundedCornerShape(14.dp))
                .padding(5.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(Purple),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.GridView, null, tint = Color.White)
            }
        }
    }
}

@Composable
private fun CharacterCard(
    image: Int,
    title: String,
    favorite: Boolean,
    onFavorite: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF1A203B), Color(0xFF0D1229))
                )
            )
            .border(1.dp, Line, RoundedCornerShape(22.dp))
            .padding(7.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(.65f)
                .clip(RoundedCornerShape(18.dp))
        ) {
            Image(
                painter = painterResource(image),
                contentDescription = title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(7.dp)
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = .35f))
                    .clickable { onFavorite() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (favorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    null,
                    tint = if (favorite) Color(0xFFFF4E70) else Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            title,
            color = Color.White,
            fontSize = 17.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1
        )
        Text(
            "★★★★★",
            color = Color(0xFFFFCF42),
            fontSize = 13.sp,
            letterSpacing = 0.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.SouthEast, null, tint = TextMuted, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(4.dp))
            Text("Polearm", color = TextMuted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(5.dp))
    }
}

@Composable
private fun FloatingBottomBar(
    selected: Int,
    onSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val labels = listOf("Characters", "Weapons", "Artifacts", "Teams", "Tier List")
    val icons = listOf(
        Icons.Default.Person,
        Icons.Default.Shield,
        Icons.Default.AutoAwesome,
        Icons.Default.Groups,
        Icons.Default.Leaderboard
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(88.dp),
        shape = RoundedCornerShape(36.dp),
        color = Color(0xFF0D111B),
        tonalElevation = 10.dp,
        shadowElevation = 18.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            labels.forEachIndexed { index, label ->
                val active = selected == index
                val width by animateDpAsState(
                    targetValue = if (active) 210.dp else 66.dp,
                    label = "navWidth"
                )
                Box(
                    modifier = Modifier
                        .height(64.dp)
                        .width(width)
                        .clip(RoundedCornerShape(30.dp))
                        .background(if (active) Purple else Color.Transparent)
                        .clickable { onSelected(index) },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            icons[index],
                            null,
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                        if (active) {
                            Spacer(Modifier.width(12.dp))
                            AnimatedContent(targetState = label, label = "navLabel") {
                                Text(
                                    it,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
